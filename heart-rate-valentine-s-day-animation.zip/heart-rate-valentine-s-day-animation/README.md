# 💝heart rate valentine's day animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/uchardon/pen/VwMNjox](https://codepen.io/uchardon/pen/VwMNjox).

heart rate line animation for valetine's day