# 💖heart 〽 line animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/uchardon/pen/YzrgRrY](https://codepen.io/uchardon/pen/YzrgRrY).

Happy Valentine's Day Animation, a heart line draw svg animation love me