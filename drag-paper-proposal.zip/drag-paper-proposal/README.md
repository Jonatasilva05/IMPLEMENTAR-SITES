# Drag paper proposal

A Pen created on CodePen.io. Original URL: [https://codepen.io/devsaro/pen/wvYPaRg](https://codepen.io/devsaro/pen/wvYPaRg).

